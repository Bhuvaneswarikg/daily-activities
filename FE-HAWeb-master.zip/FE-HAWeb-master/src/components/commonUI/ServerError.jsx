import React, { Fragment } from 'react';
import { Row, Col } from 'react-bootstrap';
import Select from 'react-select';
import SelectStyles from '../../common/SelectStyles';

const ServerError = (props) => {
  return (
    <Fragment>
      {/* <IonToolbar className='homeHeader' color="primary">
            <IonTitle>Server error</IonTitle>
      </IonToolbar> */}
      <div>Server Error</div>
    </Fragment>
  );
};


export default ServerError;
